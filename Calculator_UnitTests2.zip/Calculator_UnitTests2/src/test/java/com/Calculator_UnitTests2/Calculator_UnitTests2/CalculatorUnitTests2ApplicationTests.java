package com.Calculator_UnitTests2.Calculator_UnitTests2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculatorUnitTests2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
