package com.Calculator_UnitTests2.Calculator_UnitTests2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculatorUnitTests2Application {

	public static void main(String[] args) {
		SpringApplication.run(CalculatorUnitTests2Application.class, args);
	}

}
